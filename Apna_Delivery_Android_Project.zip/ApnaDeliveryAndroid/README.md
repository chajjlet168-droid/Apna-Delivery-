# Apna Delivery Android Project

This Android Studio project wraps the existing Apna Delivery V6 HTML app in a native Android WebView.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync/download Android SDK components.
3. Build > Build APK(s).
4. APK will be under `app/build/outputs/apk/debug/`.

Application ID: `com.apnadelivery.app`
Version: 1.0 (code 1)
